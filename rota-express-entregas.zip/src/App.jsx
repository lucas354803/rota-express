import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion } from "framer-motion";
import { Bike, MapPin, Package, Plus, ShieldCheck, UserRound, ClipboardList, Phone, Navigation } from "lucide-react";
import "./style.css";

const statusLabels = {
  aguardando: "Aguardando motoboy",
  aceita: "Corrida aceita",
  coletado: "Pedido coletado",
  entregue: "Entrega finalizada",
};

function calcValue(km) {
  const distance = Number(km || 0);
  if (!distance || distance <= 0) return 0;
  if (distance <= 3) return 8;
  if (distance <= 6) return 10;
  return Math.ceil(10 + (distance - 6) * 2);
}

function money(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function App() {
  const [screen, setScreen] = useState("cliente");
  const [orders, setOrders] = useState([
    {
      id: 1001,
      loja: "Big Burger",
      cliente: "Cliente teste",
      telefone: "48999999999",
      coleta: "Av. Principal, 100 - Centro",
      entrega: "Rua das Flores, 45 - Aurora",
      obs: "Entregar na portaria",
      km: 4.2,
      valor: 10,
      motoboy: "",
      status: "aguardando",
      createdAt: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    },
  ]);

  const [form, setForm] = useState({
    loja: "", cliente: "", telefone: "", coleta: "", entrega: "", obs: "", km: "",
  });

  const previewValue = useMemo(() => calcValue(form.km), [form.km]);
  const total = orders.reduce((acc, item) => acc + item.valor, 0);
  const finalized = orders.filter((item) => item.status === "entregue").length;

  function createOrder(e) {
    e.preventDefault();
    if (!form.coleta || !form.entrega || !form.km) return;

    const newOrder = {
      id: Date.now(),
      loja: form.loja || "Cliente avulso",
      cliente: form.cliente || "Sem nome",
      telefone: form.telefone,
      coleta: form.coleta,
      entrega: form.entrega,
      obs: form.obs,
      km: Number(form.km),
      valor: previewValue,
      motoboy: "",
      status: "aguardando",
      createdAt: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    };

    setOrders([newOrder, ...orders]);
    setForm({ loja: "", cliente: "", telefone: "", coleta: "", entrega: "", obs: "", km: "" });
    setScreen("admin");
  }

  function updateOrder(id, changes) {
    setOrders((current) => current.map((item) => (item.id === id ? { ...item, ...changes } : item)));
  }

  return (
    <div className="page">
      <div className="app">
        <header className="hero">
          <div className="logo"><Bike size={32} /></div>
          <div>
            <h1>Rota Express</h1>
            <p>Entregas rápidas na rota certa</p>
          </div>
        </header>

        <nav className="tabs">
          <button className={screen==="cliente" ? "active" : ""} onClick={() => setScreen("cliente")}><Package size={18}/>Cliente</button>
          <button className={screen==="motoboy" ? "active" : ""} onClick={() => setScreen("motoboy")}><Bike size={18}/>Motoboy</button>
          <button className={screen==="admin" ? "active" : ""} onClick={() => setScreen("admin")}><ShieldCheck size={18}/>Admin</button>
        </nav>

        {screen === "cliente" && (
          <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="card white">
            <h2>Chamar motoboy</h2>
            <p className="muted">Preencha os dados da entrega.</p>
            <form onSubmit={createOrder} className="form">
              <Input icon={Package} placeholder="Nome da loja ou cliente" value={form.loja} onChange={(v) => setForm({ ...form, loja: v })} />
              <Input icon={UserRound} placeholder="Nome do cliente" value={form.cliente} onChange={(v) => setForm({ ...form, cliente: v })} />
              <Input icon={Phone} placeholder="Telefone/WhatsApp" value={form.telefone} onChange={(v) => setForm({ ...form, telefone: v })} />
              <Input icon={MapPin} placeholder="Endereço de coleta" value={form.coleta} onChange={(v) => setForm({ ...form, coleta: v })} required />
              <Input icon={Navigation} placeholder="Endereço de entrega" value={form.entrega} onChange={(v) => setForm({ ...form, entrega: v })} required />
              <Input icon={ClipboardList} placeholder="Observação" value={form.obs} onChange={(v) => setForm({ ...form, obs: v })} />
              <input className="input" type="number" min="0" step="0.1" placeholder="Distância aproximada em km" value={form.km} onChange={(e) => setForm({ ...form, km: e.target.value })} required />
              <div className="price"><span>Valor da corrida</span><strong>{money(previewValue)}</strong></div>
              <button className="mainBtn"><Plus size={20}/> Solicitar entrega</button>
            </form>
          </motion.section>
        )}

        {screen === "motoboy" && (
          <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <h2>Corridas disponíveis</h2>
            {orders.map((order) => (
              <OrderCard key={order.id} order={order}>
                {order.status === "aguardando" && <button onClick={() => updateOrder(order.id, { status: "aceita", motoboy: "Motoboy parceiro" })} className="yellowBtn">Aceitar corrida</button>}
                {order.status === "aceita" && <button onClick={() => updateOrder(order.id, { status: "coletado" })} className="whiteBtn">Pedido coletado</button>}
                {order.status === "coletado" && <button onClick={() => updateOrder(order.id, { status: "entregue" })} className="greenBtn">Finalizar entrega</button>}
                <a className="mapBtn" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.entrega)}`} target="_blank" rel="noreferrer">Abrir rota no Maps</a>
              </OrderCard>
            ))}
          </motion.section>
        )}

        {screen === "admin" && (
          <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <div className="stats">
              <Stat title="Entregas" value={orders.length} />
              <Stat title="Faturamento" value={money(total)} />
              <Stat title="Finalizadas" value={finalized} />
              <Stat title="Motoboys online" value="3" />
            </div>
            <h2>Painel de controle</h2>
            {orders.map((order) => (
              <OrderCard key={order.id} order={order}>
                <div className="gridBtns">
                  <button onClick={() => updateOrder(order.id, { status: "aceita", motoboy: "Motoboy parceiro" })}>Aceita</button>
                  <button onClick={() => updateOrder(order.id, { status: "coletado" })}>Coletado</button>
                  <button onClick={() => updateOrder(order.id, { status: "entregue" })}>Entregue</button>
                  <button className="danger" onClick={() => setOrders(orders.filter((item) => item.id !== order.id))}>Excluir</button>
                </div>
              </OrderCard>
            ))}
          </motion.section>
        )}
      </div>
    </div>
  );
}

function Input({ icon: Icon, placeholder, value, onChange, required }) {
  return <div className="field"><Icon size={18}/><input placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)} required={required}/></div>;
}

function Stat({ title, value }) {
  return <div className="stat"><span>{title}</span><strong>{value}</strong></div>;
}

function OrderCard({ order, children }) {
  return (
    <div className="order">
      <div className="orderTop">
        <div><b>#{order.id}</b><small>{order.loja} • {order.createdAt}</small></div>
        <span className={"badge " + order.status}>{statusLabels[order.status]}</span>
      </div>
      <p><b>Cliente:</b> {order.cliente}</p>
      <p><b>Coleta:</b> {order.coleta}</p>
      <p><b>Entrega:</b> {order.entrega}</p>
      {order.obs && <p><b>Obs:</b> {order.obs}</p>}
      <p><b>Distância:</b> {order.km} km</p>
      <h3>{money(order.valor)}</h3>
      <div className="actions">{children}</div>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
